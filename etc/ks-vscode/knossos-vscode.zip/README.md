# Knossos ks-lisp

A VS Code extension for the Knossos lisp-like IR

## Requirements

None

<!---

## Extension Settings

Include if your extension adds any VS Code settings through the `contributes.configuration` extension point.

For example:

This extension contributes the following settings:

* `myExtension.enable`: enable/disable this extension
* `myExtension.thing`: set to `blah` to do something

--->

## Known Issues

None yet.

## Release Notes

Users appreciate release notes as you update your extension.

### 1.0.0

Initial release of ...
